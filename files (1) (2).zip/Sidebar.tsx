import React, { useState, useContext } from 'react';
import {
  Bars3Icon,
  XMarkIcon,
  ArrowRightOnRectangleIcon,
  LockClosedIcon,
  ShieldCheckIcon,
} from '@heroicons/react/24/outline';
import { AuthContext } from '../contexts/AuthContext';
import { PermissionsMap } from './AdminPermissionsPage';

interface NavItemProps {
  label: string;
  active?: boolean;
  locked?: boolean;
  onClick: () => void;
}

interface HorizontalSidebarProps {
  activeItem: string;
  onNavigate: (item: string) => void;
  permissions: PermissionsMap;
}

const NavItem: React.FC<NavItemProps> = ({ label, active, locked, onClick }) => {
  return (
    <li
      onClick={onClick}
      className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors duration-200
        ${active ? 'bg-blue-50 text-blue-600 font-semibold' : locked ? 'text-gray-300' : 'text-gray-600 hover:bg-gray-100'}
        lg:p-0 lg:bg-transparent`}
    >
      <span className="ml-3 lg:ml-0 flex items-center gap-1">
        {label}
        {locked && <LockClosedIcon className="h-3 w-3 inline ml-1 text-gray-300" />}
      </span>
    </li>
  );
};

const HorizontalSidebar: React.FC<HorizontalSidebarProps> = ({
  activeItem,
  onNavigate,
  permissions,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout } = useContext(AuthContext);

  const isAdmin = user?.role === 'Admin';

  const navItems = [
    { id: 'Dashboard',      label: 'Dashboard' },
    { id: 'Envanter',       label: 'Envanter' },
    { id: 'Self Service',   label: 'Self Service' },
    { id: 'Ansible',        label: 'Ansible' },
    { id: 'Performance',    label: 'Performance' },
    { id: 'AskGT',          label: 'AskGT' },
    { id: 'Nöbet Listesi',  label: 'Nöbet Listesi' },
    { id: 'Önemli Linkler', label: 'Önemli Linkler' },
  ];

  const canAccess = (pageId: string) =>
    isAdmin || (permissions[pageId]?.read ?? false);

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-20">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">BMW Portal</h1>
          </div>

          {/* Desktop nav */}
          <nav className="hidden lg:flex flex-1 justify-center">
            <ul className="flex items-center space-x-6 xl:space-x-8">
              {navItems.map((item) => {
                const accessible = canAccess(item.id);
                return (
                  <a
                    href="#"
                    key={item.id}
                    title={!accessible ? 'Bu sayfaya erişim yetkiniz yok' : undefined}
                    className={`text-sm font-medium transition-colors duration-200 flex items-center gap-1
                      ${activeItem === item.id
                        ? 'text-blue-600 font-semibold'
                        : accessible
                        ? 'text-gray-500 hover:text-gray-900'
                        : 'text-gray-300 cursor-default'}`}
                    onClick={(e) => {
                      e.preventDefault();
                      onNavigate(item.id);
                    }}
                  >
                    {item.label}
                    {!accessible && (
                      <LockClosedIcon className="h-3 w-3 text-gray-300" />
                    )}
                  </a>
                );
              })}

              {/* Admin Panel linki — sadece admin'e */}
              {isAdmin && (
                <a
                  href="#"
                  className={`text-sm font-medium transition-colors duration-200 flex items-center gap-1
                    ${activeItem === 'Admin Panel'
                      ? 'text-blue-600 font-semibold'
                      : 'text-blue-500 hover:text-blue-700'}`}
                  onClick={(e) => { e.preventDefault(); onNavigate('Admin Panel'); }}
                >
                  <ShieldCheckIcon className="h-4 w-4" />
                  Yetki Yönetimi
                </a>
              )}
            </ul>
          </nav>

          {/* User info & logout */}
          <div className="flex items-center space-x-4">
            <div className="hidden sm:flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <img
                  src="https://picsum.photos/seed/user-avatar/40/40"
                  alt="User Avatar"
                  className="h-9 w-9 rounded-full"
                />
                <div>
                  <p className="font-semibold text-sm text-gray-700 capitalize leading-tight">
                    {user?.username}
                  </p>
                  <p className={`text-xs leading-tight ${isAdmin ? 'text-blue-500' : 'text-gray-400'}`}>
                    {user?.role}
                  </p>
                </div>
              </div>
              <button
                onClick={logout}
                className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors duration-200"
                title="Logout"
              >
                <ArrowRightOnRectangleIcon className="h-6 w-6" />
              </button>
            </div>

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100"
            >
              {isMenuOpen ? <XMarkIcon className="h-6 w-6" /> : <Bars3Icon className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="lg:hidden bg-white border-t border-gray-200">
          <nav className="p-4">
            <ul>
              {navItems.map((item) => (
                <NavItem
                  key={item.id}
                  label={item.label}
                  active={activeItem === item.id}
                  locked={!canAccess(item.id)}
                  onClick={() => { onNavigate(item.id); setIsMenuOpen(false); }}
                />
              ))}

              {isAdmin && (
                <li
                  onClick={() => { onNavigate('Admin Panel'); setIsMenuOpen(false); }}
                  className={`flex items-center gap-2 p-3 rounded-lg cursor-pointer transition-colors duration-200 mt-1
                    ${activeItem === 'Admin Panel' ? 'bg-blue-50 text-blue-600 font-semibold' : 'text-blue-500 hover:bg-blue-50'}`}
                >
                  <ShieldCheckIcon className="h-4 w-4 ml-3" />
                  <span className="text-sm">Yetki Yönetimi</span>
                </li>
              )}

              <li className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <img
                      src="https://picsum.photos/seed/user-avatar/40/40"
                      alt="User Avatar"
                      className="h-9 w-9 rounded-full"
                    />
                    <div>
                      <p className="font-semibold text-sm text-gray-700 capitalize">{user?.username}</p>
                      <p className={`text-xs ${isAdmin ? 'text-blue-500' : 'text-gray-400'}`}>{user?.role}</p>
                    </div>
                  </div>
                  <button
                    onClick={logout}
                    className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full"
                  >
                    <ArrowRightOnRectangleIcon className="h-6 w-6" />
                  </button>
                </div>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default HorizontalSidebar;
