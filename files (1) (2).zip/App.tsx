import React, { useContext, useState } from 'react';
import Sidebar from './components/Sidebar';
import DashboardPage from './components/DashboardPage';
import PageComponent from './components/PageComponent';
import ImportantLinksPage from './components/ImportantLinksPage';
import DutyRosterPage from './components/DutyRosterPage';
import EnvanterPage from './components/EnvanterPage';
import LoginPage from './components/LoginPage';
import SessionTimeoutModal from './components/SessionTimeoutModal';
import AskGTPage from './components/AskGTPage';
import AdminPermissionsPage, {
  DEFAULT_PERMISSIONS,
  PermissionsMap,
} from './components/AdminPermissionsPage';
import { AuthContext } from './contexts/AuthContext';
import { PAGE_CONFIG } from './constants';
import PerformancePage from './components/PerformancePage';

const AppContent: React.FC = () => {
  const { user } = useContext(AuthContext);
  const [activePage, setActivePage] = React.useState('Dashboard');
  const [permissions, setPermissions] = useState<PermissionsMap>(DEFAULT_PERMISSIONS);

  const isAdmin = user?.role === 'Admin';

  // Normal user için erişim kontrolü
  const canAccess = (pageId: string): boolean => {
    if (isAdmin) return true;
    return permissions[pageId]?.read ?? false;
  };

  const handleNavigate = (page: string) => {
    if (canAccess(page) || page === 'Admin Panel') {
      setActivePage(page);
    }
  };

  const renderContent = () => {
    // Admin Panel — sadece admin görebilir
    if (activePage === 'Admin Panel' && isAdmin) {
      return (
        <AdminPermissionsPage
          permissions={permissions}
          onChange={setPermissions}
        />
      );
    }

    // Erişim yoksa kilitli ekran
    if (!canAccess(activePage)) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
          <div className="text-5xl mb-4">🔒</div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">Erişim Yetkiniz Yok</h2>
          <p className="text-gray-500 max-w-sm">
            <strong>{activePage}</strong> sayfasını görüntüleme yetkiniz bulunmuyor.
            Erişim için sistem yöneticinizle iletişime geçin.
          </p>
        </div>
      );
    }

    if (activePage === 'Dashboard') {
      return <DashboardPage onNavigate={handleNavigate} />;
    }
    if (activePage === 'Envanter') {
      return <EnvanterPage />;
    }
    if (activePage === 'Önemli Linkler') {
      return <ImportantLinksPage />;
    }
    if (activePage === 'Nöbet Listesi') {
      return <DutyRosterPage />;
    }
    if (activePage === 'Performance') {
      return <PerformancePage />;
    }
    if (activePage === 'AskGT') {
      return <AskGTPage />;
    }

    const config = PAGE_CONFIG[activePage];
    if (config) {
      return <PageComponent title={activePage} tabsConfig={config.tabs} />;
    }
    return <PageComponent title={activePage} tabsConfig={[]} />;
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Sidebar
        activeItem={activePage}
        onNavigate={handleNavigate}
        permissions={permissions}
      />
      <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
};

const App: React.FC = () => {
  const { isAuthenticated, showTimeoutModal, extendSession, logout, countdown } =
    useContext(AuthContext);

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return (
    <>
      <AppContent />
      <SessionTimeoutModal
        isOpen={showTimeoutModal}
        countdown={countdown}
        onExtend={extendSession}
        onLogout={logout}
      />
    </>
  );
};

export default App;
