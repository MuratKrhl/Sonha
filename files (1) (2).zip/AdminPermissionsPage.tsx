import React, { useState } from 'react';
import { ShieldCheckIcon } from '@heroicons/react/24/outline';

// Sayfaların listesi — Sidebar'daki navItems ile eşleşmeli
const MANAGED_PAGES = [
  { id: 'Dashboard',      label: 'Dashboard' },
  { id: 'Envanter',       label: 'Envanter' },
  { id: 'Self Service',   label: 'Self Service' },
  { id: 'Ansible',        label: 'Ansible' },
  { id: 'Performance',    label: 'Performance' },
  { id: 'AskGT',          label: 'AskGT' },
  { id: 'Nöbet Listesi',  label: 'Nöbet Listesi' },
  { id: 'Önemli Linkler', label: 'Önemli Linkler' },
];

export interface PagePermission {
  read: boolean;
  write: boolean;
}

export type PermissionsMap = Record<string, PagePermission>;

// Default: User sadece Dashboard'u görebilir
export const DEFAULT_PERMISSIONS: PermissionsMap = Object.fromEntries(
  MANAGED_PAGES.map((p) => [p.id, { read: p.id === 'Dashboard', write: false }])
);

interface Props {
  permissions: PermissionsMap;
  onChange: (updated: PermissionsMap) => void;
}

const Toggle: React.FC<{ checked: boolean; onChange: () => void; disabled?: boolean }> = ({
  checked, onChange, disabled,
}) => (
  <button
    type="button"
    disabled={disabled}
    onClick={onChange}
    className={`relative inline-flex h-5 w-9 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none
      ${checked ? 'bg-blue-600' : 'bg-gray-200'}
      ${disabled ? 'opacity-40 cursor-not-allowed' : ''}`}
  >
    <span
      className={`inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out
        ${checked ? 'translate-x-4' : 'translate-x-0'}`}
    />
  </button>
);

const AdminPermissionsPage: React.FC<Props> = ({ permissions, onChange }) => {
  const [saved, setSaved] = useState(false);
  const [local, setLocal] = useState<PermissionsMap>(permissions);

  const toggle = (pageId: string, type: 'read' | 'write') => {
    setLocal((prev) => {
      const current = prev[pageId];
      // Okuma kapatılırsa yazma da kapanır
      if (type === 'read' && current.read) {
        return { ...prev, [pageId]: { read: false, write: false } };
      }
      return { ...prev, [pageId]: { ...current, [type]: !current[type] } };
    });
    setSaved(false);
  };

  const handleSave = () => {
    onChange(local);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-blue-50 rounded-lg">
          <ShieldCheckIcon className="h-6 w-6 text-blue-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-900">Kullanıcı Yetki Yönetimi</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Normal kullanıcıların hangi sayfalara erişebileceğini ayarlayın.
          </p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
        {/* Table header */}
        <div className="grid grid-cols-[1fr_100px_100px] px-5 py-3 bg-gray-50 border-b border-gray-200">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Sayfa</span>
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider text-center">Görüntüle</span>
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider text-center">Düzenle</span>
        </div>

        {MANAGED_PAGES.map((page, i) => {
          const perm = local[page.id] ?? { read: false, write: false };
          return (
            <div
              key={page.id}
              className={`grid grid-cols-[1fr_100px_100px] px-5 py-4 items-center
                ${i < MANAGED_PAGES.length - 1 ? 'border-b border-gray-100' : ''}
                hover:bg-gray-50 transition-colors duration-100`}
            >
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium text-gray-800">{page.label}</span>
                {!perm.read && (
                  <span className="text-xs bg-gray-100 text-gray-400 px-2 py-0.5 rounded-full">Erişim Yok</span>
                )}
                {perm.read && !perm.write && (
                  <span className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">Salt Okunur</span>
                )}
                {perm.read && perm.write && (
                  <span className="text-xs bg-amber-50 text-amber-600 px-2 py-0.5 rounded-full">Tam Yetki</span>
                )}
              </div>

              <div className="flex justify-center">
                <Toggle
                  checked={perm.read}
                  onChange={() => toggle(page.id, 'read')}
                />
              </div>

              <div className="flex justify-center">
                <Toggle
                  checked={perm.write}
                  onChange={() => toggle(page.id, 'write')}
                  disabled={!perm.read}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-4">
        <p className="text-xs text-gray-400">
          💡 Düzenleme yetkisi için önce görüntüleme aktif olmalıdır. Admin kullanıcılar her zaman tam yetkiye sahiptir.
        </p>
        <button
          onClick={handleSave}
          className={`px-5 py-2 rounded-lg text-sm font-semibold text-white transition-colors duration-200
            ${saved ? 'bg-green-500' : 'bg-blue-600 hover:bg-blue-700'}`}
        >
          {saved ? '✓ Kaydedildi' : 'Kaydet'}
        </button>
      </div>
    </div>
  );
};

export default AdminPermissionsPage;
