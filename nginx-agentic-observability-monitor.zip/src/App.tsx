/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Activity, Terminal, Shield, FileCode, Clock, Server, Monitor, HeartPulse, RefreshCw } from 'lucide-react';
import { RealtimeStats, ToolMetric, McpLogEntry } from './types';
import { SCENARIOS, INITIAL_METRICS } from './data';
import { NginxLogTerminal } from './components/NginxLogTerminal';
import { ConfigFileExplorer } from './components/ConfigFileExplorer';
import { MetricsDashboard } from './components/MetricsDashboard';
import { PlaygroundSimulator } from './components/PlaygroundSimulator';

// Generate some authentic historical logs to populate on load
const generateInitialLogs = (): McpLogEntry[] => {
  const initialLogs: McpLogEntry[] = [];
  const startStamp = Date.now() - 3600000; // 1 hour ago
  
  const sampleLogPresets = [
    { client: 'claude-3-5-sonnet', method: 'tools/list', tool: '-', status: 'success' as const, latency: 62, size: 310 },
    { client: 'gemini-1-5-pro', method: 'tools/call', tool: 'query_production_database', status: 'success' as const, latency: 312, size: 485 },
    { client: 'gpt-4o', method: 'tools/call', tool: 'search_vector_store', status: 'success' as const, latency: 1720, size: 812 },
    { client: 'claude-3-haiku', method: 'tools/call', tool: 'fetch_realtime_weather', status: 'error' as const, err: 'Invalid coordinates boundaries', latency: 145, size: 215 },
    { client: 'custom-internal-agent', method: 'tools/call', tool: 'run_sandboxed_test', status: 'timeout' as const, latency: 3000, size: 610 },
    { client: 'gemini-1-5-pro', method: 'tools/list', tool: '-', status: 'success' as const, latency: 45, size: 290 },
    { client: 'gpt-4o-mini', method: 'tools/call', tool: 'fetch_realtime_weather', status: 'success' as const, latency: 110, size: 342 }
  ];

  sampleLogPresets.forEach((sample, idx) => {
    const elapsed = idx * 450000; // 7.5 mins apart
    const date = new Date(startStamp + elapsed);
    const entryId = `hist-${idx}`;
    
    let rawLogLine = `127.0.0.1 - - [${date.toISOString()}] "POST /mcp HTTP/1.1" ${sample.status === 'timeout' ? '504' : '200'} ${sample.size} "-" "${sample.client}" mcp_method="${sample.method}" mcp_tool="${sample.tool}" mcp_status="${sample.status}" rt=${(sample.latency/1000).toFixed(3)}s`;

    initialLogs.push({
      id: entryId,
      timestamp: date.toLocaleTimeString(),
      remoteAddr: '192.168.1.45',
      client: sample.client,
      httpMethod: 'POST',
      path: '/mcp',
      httpStatus: sample.status === 'timeout' ? 504 : 200,
      bodyBytesSent: sample.size,
      mcpMethod: sample.method,
      mcpToolName: sample.tool,
      latencyMs: sample.latency,
      status: sample.status,
      errorMessage: sample.err,
      rawLog: rawLogLine
    });
  });

  return initialLogs;
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'playground' | 'configs' | 'logs'>('dashboard');
  
  // Real-time metrics and state
  const [stats, setStats] = useState<RealtimeStats>({
    totalRequests: 708,
    successCount: 662,
    errorCount: 34,
    timeoutCount: 12,
    avgLatencyMs: 382,
    bytesTransferred: 284152
  });

  const [toolMetrics, setToolMetrics] = useState<ToolMetric[]>(INITIAL_METRICS);
  const [logs, setLogs] = useState<McpLogEntry[]>([]);

  // Initialize logs on load
  useEffect(() => {
    setLogs(generateInitialLogs());
  }, []);

  // Formats real-time stats increment
  const handleIncrementStats = (latencyMs: number, isError: boolean, isTimeout: boolean, bytes: number) => {
    setStats((prev) => {
      const nextTotal = prev.totalRequests + 1;
      const nextSuccess = prev.successCount + (!isError && !isTimeout ? 1 : 0);
      const nextError = prev.errorCount + (isError ? 1 : 0);
      const nextTimeout = prev.timeoutCount + (isTimeout ? 1 : 0);
      const nextAvg = Math.round((prev.avgLatencyMs * prev.totalRequests + latencyMs) / nextTotal);
      
      return {
        totalRequests: nextTotal,
        successCount: nextSuccess,
        errorCount: nextError,
        timeoutCount: nextTimeout,
        avgLatencyMs: nextAvg,
        bytesTransferred: prev.bytesTransferred + bytes
      };
    });
  };

  // Safe handler appending dynamically timed requests to charts
  const handleAddNewLog = (newLog: McpLogEntry) => {
    setLogs((prev) => {
      // Limit list to prevent DOM swelling
      const limited = prev.length > 150 ? prev.slice(prev.length - 150) : prev;
      return [...limited, newLog];
    });

    // Also increment individual tool specific aggregate chart items
    if (newLog.mcpMethod === 'tools/call' && newLog.mcpToolName !== '-') {
      setToolMetrics((prevMetrics) =>
        prevMetrics.map((met) => {
          if (met.name === newLog.mcpToolName) {
            const nextCalls = met.calls + 1;
            const nextAvg = Math.round((met.avgLatencyMs * met.calls + newLog.latencyMs) / nextCalls);
            return {
              ...met,
              calls: nextCalls,
              avgLatencyMs: nextAvg,
              errors: met.errors + (newLog.status === 'error' ? 1 : 0)
            };
          }
          return met;
        })
      );
    } else if (newLog.mcpMethod === 'tools/list') {
      setToolMetrics((prevMetrics) =>
        prevMetrics.map((met) => {
          if (met.name === 'tools_list') {
            const nextCalls = met.calls + 1;
            const nextAvg = Math.round((met.avgLatencyMs * met.calls + newLog.latencyMs) / nextCalls);
            return {
              ...met,
              calls: nextCalls,
              avgLatencyMs: nextAvg
            };
          }
          return met;
        })
      );
    }
  };

  const handleClearLogs = () => {
    setLogs([]);
  };

  return (
    <div id="nginx-app-viewport" className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col selection:bg-emerald-500/20 selection:text-emerald-400">
      {/* Top Navigation Global Header */}
      <header className="border-b border-zinc-900 bg-zinc-950/70 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Nginx Logo Vibe Accent */}
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-950/40 border border-emerald-400/20">
              <span className="font-mono text-zinc-950 font-black text-sm tracking-tighter">NJS</span>
            </div>
            
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <h1 className="text-sm font-bold font-display tracking-tight text-zinc-100 uppercase sm:normal-case">
                  Nginx Agentic Observability
                </h1>
                <span className="text-[9px] font-bold text-emerald-400 bg-emerald-950/50 border border-emerald-900/40 px-1.5 py-0.5 rounded uppercase font-mono">
                  v1.0.2 (MCP)
                </span>
              </div>
              <p className="text-[10px] text-zinc-500 hidden sm:block font-sans">
                Real-time Model Context Protocol Telemetry Engine
              </p>
            </div>
          </div>

          {/* Connection diagnostics block */}
          <div className="flex items-center gap-4 text-xs font-mono">
            {/* Nginx proxy status indicator */}
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-zinc-900/50 border border-zinc-800/80 rounded-lg">
              <HeartPulse size={12} className="text-emerald-400 animate-pulse" />
              <span className="text-[10px] text-zinc-400">PROXY: <span className="text-emerald-400 font-bold">ONLINE</span></span>
            </div>

            {/* Time */}
            <div className="flex items-center gap-1.5 text-zinc-500 text-[10px] bg-zinc-900/30 px-2 py-1 rounded-md border border-zinc-900/60">
              <Clock size={11} className="text-zinc-600" />
              <span>UTC: 12:09:28</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-8">
        
        {/* Navigation Selector Tabs Bar */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-px">
          <div className="flex items-center gap-1 sm:gap-2 -mb-px overflow-x-auto scroller-hidden">
            {[
              { id: 'dashboard', label: 'Observability Hub', icon: Activity },
              { id: 'playground', label: 'Interception Sandbox', icon: Monitor },
              { id: 'logs', label: 'Access Logs Stream', icon: Terminal },
              { id: 'configs', label: 'NJS Config Code', icon: FileCode }
            ].map((tab) => {
              const TabIcon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-4 py-3 border-b-2 font-medium text-xs sm:text-sm tracking-wide transition-all whitespace-nowrap ${
                    isActive
                      ? 'border-emerald-500 text-emerald-400 font-bold bg-emerald-500/[0.01]'
                      : 'border-transparent text-zinc-500 hover:text-zinc-300 hover:border-zinc-800'
                  }`}
                >
                  <TabIcon size={14} className={isActive ? 'text-emerald-400' : 'text-zinc-500'} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="text-[10px] text-zinc-500 font-mono hidden lg:flex items-center gap-2">
            <span>Interception Buffer: <span className="text-zinc-300">Active</span></span>
            <span className="h-1 w-1 bg-zinc-700 rounded-full" />
            <span>NJS Parse thread: <span className="text-zinc-300">Core #0</span></span>
          </div>
        </div>

        {/* Dynamic Inner Tab View */}
        <div id="applet-primary-content" className="flex-1">
          {activeTab === 'dashboard' && (
            <MetricsDashboard stats={stats} toolMetrics={toolMetrics} />
          )}

          {activeTab === 'playground' && (
            <div className="space-y-8">
              {/* Simulator interaction module */}
              <PlaygroundSimulator
                onTriggerLog={handleAddNewLog}
                onIncrementStats={handleIncrementStats}
              />
              
              {/* Embedded micro live logs so users can instantly inspect results within the playground */}
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-widest font-mono">
                    Telemetry Stream (Filtered: Playground Runs)
                  </h4>
                  <span className="text-[10px] text-zinc-600 font-mono">Real-time log buffer</span>
                </div>
                <NginxLogTerminal logs={logs} onClear={handleClearLogs} />
              </div>
            </div>
          )}

          {activeTab === 'logs' && (
            <div className="space-y-4">
              <div className="p-4 bg-zinc-900/20 border border-zinc-800/40 rounded-xl">
                <h3 className="text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5 font-mono">
                  Understanding NJS Stream Logging
                </h3>
                <p className="text-xs text-zinc-500 max-w-4xl leading-relaxed">
                  Every request entering the <code className="text-teal-400 font-mono bg-zinc-900 px-1.5 py-0.5 rounded text-[11px]">/mcp</code> block undergoes live body scanning. Custom variables extracted by NJS are logged locally. Select <code className="text-[11px] text-zinc-300 font-bold">Interception Sandbox</code> to run additional requests and watch lines update immediately.
                </p>
              </div>
              <NginxLogTerminal logs={logs} onClear={handleClearLogs} />
            </div>
          )}

          {activeTab === 'configs' && (
            <ConfigFileExplorer />
          )}
        </div>
      </main>

      {/* Primary Footer */}
      <footer className="border-t border-zinc-900 bg-zinc-950 py-6 mt-16 text-zinc-500 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-sans text-[11px]">
            &copy; {new Date().getFullYear()} Nginx Agentic Observability Console. Built following <code className="text-zinc-400 font-mono">nginx-mcp-js</code> design specs.
          </p>
          <div className="flex items-center gap-6 font-mono text-[10px]">
            <a
              href="https://github.com/nginx/nginx-mcp-js"
              target="_blank"
              rel="noreferrer"
              className="hover:text-emerald-400 transition-colors flex items-center gap-1"
            >
              <Server size={11} />
              <span>Official GitHub Repo</span>
            </a>
            <span>Status: Operational (NJS runtime loaded)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
