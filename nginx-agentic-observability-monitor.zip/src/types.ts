/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface McpRequestScenario {
  id: string;
  name: string;
  subtitle: string;
  method: string;
  toolName?: string;
  clientName: string;
  latencyRange: [number, number]; // min, max ms
  status: 'success' | 'error' | 'timeout';
  requestBody: Record<string, any>;
  responseBody: Record<string, any>;
  description: string;
}

export interface McpLogEntry {
  id: string;
  timestamp: string;
  remoteAddr: string;
  client: string;
  httpMethod: string;
  path: string;
  httpStatus: number;
  bodyBytesSent: number;
  mcpMethod: string;
  mcpToolName: string;
  latencyMs: number;
  status: 'success' | 'error' | 'timeout'; // MCP level status
  errorMessage?: string;
  rawLog: string;
}

export interface ToolMetric {
  name: string;
  displayName: string;
  calls: number;
  avgLatencyMs: number;
  errors: number;
}

export interface RealtimeStats {
  totalRequests: number;
  successCount: number;
  errorCount: number;
  timeoutCount: number;
  avgLatencyMs: number;
  bytesTransferred: number;
}
