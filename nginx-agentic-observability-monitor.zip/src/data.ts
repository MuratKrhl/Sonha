/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { McpRequestScenario } from './types';

export const SCENARIOS: McpRequestScenario[] = [
  {
    id: 'list-tools',
    name: 'Tool Discovery',
    subtitle: 'Claude Agent discovers capability checklist',
    method: 'tools/list',
    clientName: 'claude-3-5-sonnet',
    latencyRange: [45, 90],
    status: 'success',
    description: 'The agent initiates a discovery handshake by fetching all declared tools together with their JSON schema parameters.',
    requestBody: {
      jsonrpc: '2.0',
      method: 'tools/list',
      id: 101,
      params: {}
    },
    responseBody: {
      jsonrpc: '2.0',
      result: {
        tools: [
          { name: 'query_production_database', description: 'Executes analytical SQL read queries', inputSchema: { type: 'object', properties: { query: { type: 'string' } } } },
          { name: 'search_vector_store', description: 'Retrieves relevant high-dimensional embeddings segments', inputSchema: { type: 'object', properties: { prompt: { type: 'string' } } } },
          { name: 'fetch_realtime_weather', description: 'Acquires current meteorological details', inputSchema: { type: 'object', properties: { lat: { type: 'number' }, lon: { type: 'number' } } } }
        ]
      },
      id: 101
    }
  },
  {
    id: 'db-query-success',
    name: 'Database Fetch',
    subtitle: 'Healthy tool call reading standard transactional tables',
    method: 'tools/call',
    toolName: 'query_production_database',
    clientName: 'gemini-1-5-pro',
    latencyRange: [220, 410],
    status: 'success',
    description: 'An AI-agent requests analytical data. The SQL query runs directly over indices, returning within normal bounds.',
    requestBody: {
      jsonrpc: '2.0',
      method: 'tools/call',
      id: 102,
      params: {
        name: 'query_production_database',
        arguments: {
          query: 'SELECT email, total_spending FROM customers_analytics WHERE ranking = "gold" LIMIT 10;'
        }
      }
    },
    responseBody: {
      jsonrpc: '2.0',
      result: {
        content: [
          {
            type: 'text',
            text: '[\n  {"email": "carol_vip@domain.com", "total_spending": 24050.22},\n  {"email": "alex_gold@domain.com", "total_spending": 18210.15}\n]'
          }
        ]
      },
      id: 102
    }
  },
  {
    id: 'high-latency-vdb',
    name: 'Heavy Vector Search',
    subtitle: 'High-latency embedding lookup across 10M records',
    method: 'tools/call',
    toolName: 'search_vector_store',
    clientName: 'gpt-4o',
    latencyRange: [1450, 2400],
    status: 'success',
    description: 'Runs semantic vector lookups. Triggers an NGINX latency warning. Highlights slow tool call monitoring.',
    requestBody: {
      jsonrpc: '2.0',
      method: 'tools/call',
      id: 103,
      params: {
        name: 'search_vector_store',
        arguments: {
          prompt: 'Retrieve legal precedents on database security breach liability and disclosure requirements.'
        }
      }
    },
    responseBody: {
      jsonrpc: '2.0',
      result: {
        content: [
          {
            type: 'text',
            text: '[Vector Segment Match #1]: "Strict liability details for entities failing to deploy reasonable multi-factor isolation layers..." (Cosine similarity: 0.912)'
          }
        ]
      },
      id: 103
    }
  },
  {
    id: 'weather-schema-error',
    name: 'Parameters Fault',
    subtitle: 'Validation crash: tool returns schema error values',
    method: 'tools/call',
    toolName: 'fetch_realtime_weather',
    clientName: 'claude-3-haiku',
    latencyRange: [110, 180],
    status: 'error',
    description: 'The parameter coordinates are missing or out of range. The server detects schema deviance and logs an explicit execution err.',
    requestBody: {
      jsonrpc: '2.0',
      method: 'tools/call',
      id: 104,
      params: {
        name: 'fetch_realtime_weather',
        arguments: {
          lat: 91.503,
          lon: -302.215
        }
      }
    },
    responseBody: {
      jsonrpc: '2.0',
      error: {
        code: -32602,
        message: 'Invalid parameter boundaries: latitude must be within [-90, 90] and longitude within [-180, 180].'
      },
      id: 104
    }
  },
  {
    id: 'timeout-sandbox',
    name: 'Hardware Timeout',
    subtitle: 'Target server hits a socket wall and drops packet',
    method: 'tools/call',
    toolName: 'run_sandboxed_test',
    clientName: 'custom-internal-agent',
    latencyRange: [3000, 3100],
    status: 'timeout',
    description: 'An execution task causes an infinite loop in the sandbox. The server times out and NGINX logs a 504 Gateway Timeout.',
    requestBody: {
      jsonrpc: '2.0',
      method: 'tools/call',
      id: 105,
      params: {
        name: 'run_sandboxed_test',
        arguments: {
          script: 'while(true) { console.log("overheat_cpu"); }'
        }
      }
    },
    responseBody: {
      jsonrpc: '2.0',
      error: {
        code: -32000,
        message: 'Sandbox Execution Timeout (3000ms limit surpassed).'
      },
      id: 105
    }
  }
];

export const INITIAL_METRICS = [
  { name: 'query_production_database', displayName: 'DB Analytical Query', calls: 142, avgLatencyMs: 312, errors: 4 },
  { name: 'search_vector_store', displayName: 'Vector Store Semantic Search', calls: 86, avgLatencyMs: 1680, errors: 2 },
  { name: 'fetch_realtime_weather', displayName: 'Weather API Integrator', calls: 215, avgLatencyMs: 145, errors: 18 },
  { name: 'run_sandboxed_test', displayName: 'Sandbox Test Runner', calls: 32, avgLatencyMs: 1980, errors: 12 },
  { name: 'tools_list', displayName: 'Capability Discovery (tools/list)', calls: 110, avgLatencyMs: 50, errors: 0 }
];

export const CONFIGS = [
  {
    id: 'nginx-conf',
    filename: 'nginx.conf',
    language: 'nginx',
    description: 'Configures NGINX to load the NJS module, bind the upstream servers, import mcp.js, extract variables from incoming JSON-RPC traffic, and record them in custom-formatted access tables.',
    code: `user  nginx;
worker_processes  auto;

# Load NGINX JavaScript (njs) Module for JSON-RPC decomposition
load_module modules/ngx_http_js_module.so;

events {
    worker_connections  1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    # Import NJS script containing parser helpers
    js_import mcp from conf.d/mcp.js;

    # Extract MCP Model Context variables from HTTP POST stream bodies
    js_set $mcp_method    mcp.getMethod;
    js_set $mcp_tool_name mcp.getToolName;
    js_set $mcp_status    mcp.getMcpStatus;

    # Custom Agentic Observability Log Format
    log_format agentic_observability '$remote_addr - [$time_local] '
                                     '"$request" $status $body_bytes_sent '
                                     'mcp_method="$mcp_method" '
                                     'mcp_tool="$mcp_tool_name" '
                                     'mcp_status="$mcp_status" '
                                     'rt=$request_time ust=$upstream_response_time';

    access_log  /var/log/nginx/mcp_access.log  agentic_observability;

    upstream mcp_backend {
        server mcp-server-1:5005;
        server mcp-server-2:5005;
        keepalive 32;
    }

    server {
        listen       80;
        server_name  localhost;

        # Keep client request bodies in memory for NJS reading parameters
        client_body_buffer_size 128k;

        location /mcp {
            proxy_pass http://mcp_backend;
            proxy_http_version 1.1;
            proxy_set_header Connection "";
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;

            # Intercept response to analyze JSON-RPC error frames
            js_header_filter mcp.analyzeResponse;
        }
    }
}`
  },
  {
    id: 'mcp-js',
    filename: 'conf.d/mcp.js',
    language: 'javascript',
    description: 'The NGINX JavaScript (njs) code responsible for safely reading and digesting client JSON-RPC bodies, and inspecting backend signals to determine MCP tool call metadata.',
    code: `/**
 * NGINX JavaScript (njs) script for Agentic Observability
 * Extracts Model Context Protocol (MCP) details safely.
 */

// Reads the raw JSON-RPC body of standard HTTP client requests
function getBody(r) {
    try {
        if (!r.requestText) {
            return null;
        }
        return JSON.parse(r.requestText);
    } catch (e) {
        return null;
    }
}

// Extract MCP Method line
function getMethod(r) {
    var body = getBody(r);
    if (!body) return "-";
    return body.method || "unknown_rpc_method";
}

// Extract MCP Tool Name (when method === "tools/call")
function getToolName(r) {
    var body = getBody(r);
    if (!body) return "-";
    
    // Tools Call RPC shape
    if (body.method === "tools/call" && body.params) {
        return body.params.name || "unnamed_tool";
    }
    
    // Prompts Fetch RPC shape
    if (body.method === "prompts/get" && body.params) {
        return body.params.name || "unnamed_prompt";
    }
    
    return "-";
}

// Determines if the MCP Call is evaluated as a success or an error inside the JSON payload
function getMcpStatus(r) {
    // Check if upstream response sent header indicating custom jsonrpc-error
    var errHeader = r.headersOut['X-MCP-Execution-Error'];
    if (errHeader) {
        return "error";
    }
    
    // Check response code of NGINX
    if (r.status >= 400) {
        return "network_failure";
    }
    
    return "success";
}

// Intercepts the back-end response header/body stream to inspect JSON-RPC error codes
function analyzeResponse(r) {
    // If the response is a successful HTTP carrier but contains JSON-RPC 'error'
    if (r.status === 200 && r.responseText) {
        try {
            var resp = JSON.parse(r.responseText);
            if (resp.error) {
                // Signal to getMcpStatus by writing a non-standard headersOut variable
                r.headersOut['X-MCP-Execution-Error'] = resp.error.message || "mcp_rpc_error";
            }
        } catch (e) {
            // response was not standard json
        }
    }
    r.action();
}

export default { getMethod, getToolName, getMcpStatus, analyzeResponse };`
  },
  {
    id: 'docker-compose',
    filename: 'docker-compose.yml',
    language: 'yaml',
    description: 'A complete configuration to spin up the entire Agentic Observability sandbox locally, mapping NGINX to two isolated Node.js MCP server backends.',
    code: `version: '3.8'

services:
  nginx-proxy:
    image: nginx:alpine-slim
    ports:
      - "8080:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./conf.d/mcp.js:/etc/nginx/conf.d/mcp.js:ro
    depends_on:
      - mcp-server-1
      - mcp-server-2

  mcp-server-1:
    image: node:20-alpine
    command: node index.js
    environment:
      - SERVER_ID=mcp-01
    volumes:
      - ./server:/app
    working_dir: /app

  mcp-server-2:
    image: node:20-alpine
    command: node index.js
    environment:
      - SERVER_ID=mcp-02
    volumes:
      - ./server:/app
    working_dir: /app`
  }
];
