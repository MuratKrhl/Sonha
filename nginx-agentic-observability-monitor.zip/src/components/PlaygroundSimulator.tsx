/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, Play, Square, Code, Shield, CheckCircle2, AlertOctagon, HelpCircle } from 'lucide-react';
import { McpRequestScenario, McpLogEntry } from '../types';
import { SCENARIOS } from '../data';

interface PlaygroundSimulatorProps {
  onTriggerLog: (log: McpLogEntry) => void;
  onIncrementStats: (latency: number, isError: boolean, isTimeout: boolean, bytes: number) => void;
}

export function PlaygroundSimulator({ onTriggerLog, onIncrementStats }: PlaygroundSimulatorProps) {
  const [selectedScenarioId, setSelectedScenarioId] = useState('list-tools');
  const [requestBodyInput, setRequestBodyInput] = useState('');
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationStep, setSimulationStep] = useState(0); // 0: Idle, 1: Client request, 2: Nginx parse, 3: Upstream run, 4: Intercept and log
  const [isContinuousMode, setIsContinuousMode] = useState(false);

  const selectedScenario = SCENARIOS.find((s) => s.id === selectedScenarioId) || SCENARIOS[0];

  useEffect(() => {
    setRequestBodyInput(JSON.stringify(selectedScenario.requestBody, null, 2));
  }, [selectedScenarioId]);

  // Handle continuous simulation timing
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isContinuousMode) {
      interval = setInterval(() => {
        // Pick a random scenario
        const randomIndex = Math.floor(Math.random() * SCENARIOS.length);
        const scenario = SCENARIOS[randomIndex];
        
        // Execute the fast trigger
        triggerQuickRun(scenario);
      }, 1400);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isContinuousMode]);

  // Simple quick trigger for auto continuous stream
  const triggerQuickRun = (scenario: McpRequestScenario) => {
    const lat = Math.floor(Math.random() * (scenario.latencyRange[1] - scenario.latencyRange[0])) + scenario.latencyRange[0];
    const isErr = scenario.status === 'error';
    const isTout = scenario.status === 'timeout';
    
    // Increment global graphs instantly
    const bodyText = JSON.stringify(scenario.requestBody);
    onIncrementStats(lat, isErr, isTout, bodyText.length);

    // Generate formatted access log
    const entryId = Math.random().toString(36).substring(7);
    const dateStr = new Date().toLocaleTimeString();
    
    let rawLogLine = `127.0.0.1 - - [${new Date().toISOString()}] "POST /mcp HTTP/1.1" ${isTout ? '504' : '200'} ${bodyText.length} "-" "${scenario.clientName}" mcp_method="${scenario.method}" mcp_tool="${scenario.toolName || '-'}" mcp_status="${scenario.status}" rt=${(lat/1000).toFixed(3)}s`;

    const logEntry: McpLogEntry = {
      id: entryId,
      timestamp: dateStr,
      remoteAddr: '192.168.1.18',
      client: scenario.clientName,
      httpMethod: 'POST',
      path: '/mcp',
      httpStatus: isTout ? 504 : 200,
      bodyBytesSent: bodyText.length,
      mcpMethod: scenario.method,
      mcpToolName: scenario.toolName || '-',
      latencyMs: lat,
      status: scenario.status,
      errorMessage: isErr ? scenario.responseBody.error?.message : undefined,
      rawLog: rawLogLine
    };

    onTriggerLog(logEntry);
  };

  // Step-by-step visual pipeline execution
  const handleStartStepByStep = async () => {
    if (isSimulating) return;
    setIsSimulating(true);
    setSimulationStep(1);

    // Step 1: Client packs payload
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setSimulationStep(2);

    // Step 2: NGINX Ingress and NJS parsed
    await new Promise((resolve) => setTimeout(resolve, 1100));
    setSimulationStep(3);

    // Step 3: Upstream backend resolves call
    const actualLatency = Math.floor(Math.random() * (selectedScenario.latencyRange[1] - selectedScenario.latencyRange[0])) + selectedScenario.latencyRange[0];
    await new Promise((resolve) => setTimeout(resolve, Math.min(actualLatency, 1800)));
    setSimulationStep(4);

    // Step 4: Header Analyzer matches rules and generates logs
    await new Promise((resolve) => setTimeout(resolve, 900));

    // Finish simulation and trigger log output
    const isErr = selectedScenario.status === 'error';
    const isTout = selectedScenario.status === 'timeout';
    
    onIncrementStats(actualLatency, isErr, isTout, requestBodyInput.length);

    const entryId = Math.random().toString(36).substring(7);
    const dateStr = new Date().toLocaleTimeString();
    
    let rawLogLine = `127.0.0.1 - - [${new Date().toISOString()}] "POST /mcp HTTP/1.1" ${isTout ? '504' : '200'} ${requestBodyInput.length} "-" "${selectedScenario.clientName}" mcp_method="${selectedScenario.method}" mcp_tool="${selectedScenario.toolName || '-'}" mcp_status="${selectedScenario.status}" rt=${(actualLatency/1000).toFixed(3)}s`;

    const logEntry: McpLogEntry = {
      id: entryId,
      timestamp: dateStr,
      remoteAddr: '202.45.10.12',
      client: selectedScenario.clientName,
      httpMethod: 'POST',
      path: '/mcp',
      httpStatus: isTout ? 504 : 200,
      bodyBytesSent: requestBodyInput.length,
      mcpMethod: selectedScenario.method,
      mcpToolName: selectedScenario.toolName || '-',
      latencyMs: actualLatency,
      status: selectedScenario.status,
      errorMessage: isErr ? selectedScenario.responseBody.error?.message : undefined,
      rawLog: rawLogLine
    };

    onTriggerLog(logEntry);

    setSimulationStep(0);
    setIsSimulating(false);
  };

  return (
    <div id="playground-simulator-wrapper" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Simulation Controls / Choices */}
      <div className="lg:col-span-5 flex flex-col space-y-4">
        {/* Scenarios Checklist selection */}
        <div className="bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-4 shadow-md space-y-3">
          <span className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest font-sans flex items-center gap-1">
            <Zap size={11} className="text-amber-400" />
            Select MCP Transaction Model
          </span>
          
          <div className="space-y-2">
            {SCENARIOS.map((scenario) => {
              const isActive = selectedScenarioId === scenario.id;
              
              let markerColor = 'bg-emerald-500';
              if (scenario.status === 'error') markerColor = 'bg-rose-500';
              if (scenario.status === 'timeout') markerColor = 'bg-amber-500';

              return (
                <button
                  key={scenario.id}
                  onClick={() => !isSimulating && setSelectedScenarioId(scenario.id)}
                  disabled={isSimulating}
                  className={`w-full flex items-start gap-3 p-2.5 rounded-xl border text-left transition-all ${
                    isActive
                      ? 'bg-zinc-800/80 border-zinc-600 text-white shadow-sm'
                      : 'bg-transparent border-transparent text-zinc-400 hover:bg-zinc-900/40 hover:text-zinc-200 disabled:opacity-50'
                  }`}
                >
                  <span className={`h-2 w-2 rounded-full mt-1.5 shrink-0 ${markerColor}`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold block truncate font-sans">
                        {scenario.name}
                      </span>
                      <span className="text-[9px] font-mono opacity-65 uppercase bg-zinc-950 px-1 hover:bg-zinc-900 border border-zinc-800/80 rounded">
                        {scenario.method.split('/')[1] || scenario.method}
                      </span>
                    </div>
                    <span className="text-[10px] text-zinc-500 block truncate leading-tight font-sans mt-0.5">
                      {scenario.subtitle}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-zinc-800/40 flex items-center justify-between">
            <span className="text-[11px] text-zinc-500 font-sans">
              Continuous agent simulation
            </span>
            <button
              onClick={() => setIsContinuousMode(!isContinuousMode)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium border transition-all ${
                isContinuousMode
                  ? 'bg-emerald-950/20 border-emerald-500/50 text-emerald-400 font-bold'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-900'
              }`}
            >
              {isContinuousMode ? <Square size={10} className="fill-emerald-400" /> : <Play size={10} />}
              <span>{isContinuousMode ? 'STOP Live Stream' : 'START Live Stream'}</span>
            </button>
          </div>
        </div>

        {/* Input parameters Body view */}
        <div className="bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-4 flex-1 flex flex-col min-h-[190px]">
          <span className="text-[10px] font-semibold text-zinc-500 uppercase tracking-widest font-sans flex items-center gap-1 mb-2">
            <Code size={11} className="text-zinc-400" />
            Outgoing Client JSON-RPC (RFC 2.0)
          </span>

          <textarea
            value={requestBodyInput}
            onChange={(e) => !isSimulating && setRequestBodyInput(e.target.value)}
            disabled={isSimulating}
            className="flex-1 w-full bg-zinc-950 border border-zinc-800/90 rounded-xl p-3 text-[11px] font-mono text-zinc-400 focus:outline-none focus:border-zinc-700 transition-colors resize-none leading-relaxed disabled:opacity-70 disabled:cursor-not-allowed select-text"
          />
        </div>
      </div>

      {/* Visual Pipeline Animation Drawer */}
      <div className="lg:col-span-7 bg-zinc-950/40 border border-zinc-830/60 rounded-2xl p-5 flex flex-col justify-between shadow-lg relative min-h-[380px]">
        <div>
          <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider font-sans flex items-center gap-1.5">
            <Shield size={12} className="text-emerald-400" />
            NJS Active Interception pipeline
          </h4>
          <p className="text-[11px] text-zinc-500 font-sans leading-relaxed">
            Click Run to trigger a dynamic call. Watch step-by-step how NGINX inspects, parses, and formats MCP analytics.
          </p>
        </div>

        {/* Node pipeline layout map */}
        <div className="py-6 flex flex-col items-center justify-around gap-6 relative flex-1">
          {/* Timeline connecting lines */}
          <div className="absolute top-2 bottom-8 w-0.5 bg-zinc-800/80 left-1/2 -translate-x-1/2 pointer-events-none" />

          {/* Connected step 1: Model Server */}
          <div className="flex items-center justify-center w-full relative z-10">
            <motion.div
              animate={{
                borderColor: simulationStep === 1 ? 'rgb(244, 63, 94)' : 'rgb(39, 39, 42)',
                backgroundColor: simulationStep === 1 ? 'rgba(244, 63, 94, 0.05)' : 'rgb(24, 24, 27)'
              }}
              className="flex items-center gap-3 px-4 py-2.5 rounded-xl border w-64 shadow-md bg-zinc-900"
            >
              <span className={`h-6 w-6 rounded-full flex items-center justify-center font-mono text-[10px] font-bold ${
                simulationStep === 1 ? 'bg-rose-500 text-white animate-pulse' : 'bg-zinc-800 text-zinc-400'
              }`}>
                01
              </span>
              <div>
                <span className="text-[11px] font-semibold text-zinc-100 block font-sans">AI Agent Client</span>
                <span className="text-[9px] font-mono text-zinc-500">model ({selectedScenario.clientName})</span>
              </div>
            </motion.div>
          </div>

          {/* Connected step 2: NGINX Ingress Proxy */}
          <div className="flex items-center justify-center w-full relative z-10">
            <motion.div
              animate={{
                borderColor: simulationStep === 2 ? 'rgb(16, 185, 129)' : 'rgb(39, 39, 42)',
                backgroundColor: simulationStep === 2 ? 'rgba(16, 185, 129, 0.05)' : 'rgb(24, 24, 27)'
              }}
              className="flex items-center gap-3 px-4 py-2.5 rounded-xl border w-64 shadow-md bg-zinc-900"
            >
              <span className={`h-6 w-6 rounded-full flex items-center justify-center font-mono text-[10px] font-bold ${
                simulationStep === 2 ? 'bg-emerald-500 text-white animate-pulse' : 'bg-zinc-800 text-zinc-400'
              }`}>
                02
              </span>
              <div>
                <span className="text-[11px] font-semibold text-zinc-100 block font-sans">NGINX Proxy Gate (NJS)</span>
                <span className="text-[9px] font-mono text-teal-400">js_import mcp / js_set</span>
              </div>
            </motion.div>
          </div>

          {/* Connected step 3: Upstream Client Target */}
          <div className="flex items-center justify-center w-full relative z-10">
            <motion.div
              animate={{
                borderColor: simulationStep === 3 ? 'rgb(168, 85, 247)' : 'rgb(39, 39, 42)',
                backgroundColor: simulationStep === 3 ? 'rgba(168, 85, 247, 0.05)' : 'rgb(24, 24, 27)'
              }}
              className="flex items-center gap-3 px-4 py-2.5 rounded-xl border w-64 shadow-md bg-zinc-900"
            >
              <span className={`h-6 w-6 rounded-full flex items-center justify-center font-mono text-[10px] font-bold ${
                simulationStep === 3 ? 'bg-purple-500 text-white animate-pulse' : 'bg-zinc-800 text-zinc-400'
              }`}>
                03
              </span>
              <div>
                <span className="text-[11px] font-semibold text-zinc-100 block font-sans">Upstream Target Farm</span>
                <span className="text-[9px] font-mono text-purple-400">mcp_backend (mcp.js analysis)</span>
              </div>
            </motion.div>
          </div>

          {/* Connected step 4: Interception Logger Access */}
          <div className="flex items-center justify-center w-full relative z-10">
            <motion.div
              animate={{
                borderColor: simulationStep === 4 ? 'rgb(234, 179, 8)' : 'rgb(39, 39, 42)',
                backgroundColor: simulationStep === 4 ? 'rgba(234, 179, 8, 0.05)' : 'rgb(24, 24, 27)'
              }}
              className="flex items-center gap-3 px-4 py-2.5 rounded-xl border w-64 shadow-md bg-zinc-900"
            >
              <span className={`h-6 w-6 rounded-full flex items-center justify-center font-mono text-[10px] font-bold ${
                simulationStep === 4 ? 'bg-amber-500 text-white animate-pulse' : 'bg-zinc-800 text-zinc-400'
              }`}>
                04
              </span>
              <div>
                <span className="text-[11px] font-semibold text-zinc-100 block font-sans">Egress Header Analysis</span>
                <span className="text-[9px] font-mono text-amber-500">mcp_access.log append</span>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Simulated status output line bar */}
        <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-between text-xs transition-all mt-4 font-mono">
          <div className="flex items-center gap-2">
            <HelpCircle size={14} className="text-zinc-500" />
            <span className="text-zinc-400">
              {simulationStep === 1 ? 'Reading outbound credentials payload...' :
               simulationStep === 2 ? 'Detecting JSON structures via NJS variables...' :
               simulationStep === 3 ? 'Executing target task on backend farm...' :
               simulationStep === 4 ? 'Resolving RPC errors and printing access files...' :
               'State: Pipeline server idle.'}
            </span>
          </div>

          <button
            onClick={handleStartStepByStep}
            disabled={isSimulating || isContinuousMode}
            className={`flex items-center gap-1 px-4 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-zinc-950 font-bold font-sans rounded-lg tracking-wide transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed`}
          >
            <Play size={12} className="fill-zinc-950" />
            <span>{isSimulating ? 'Animating...' : 'Trigger Transaction'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
