/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Activity, Clock, ShieldCheck, Database, Sliders, AlertCircle, Sparkles, TrendingUp, Cpu } from 'lucide-react';
import { ToolMetric, RealtimeStats } from '../types';

interface MetricsDashboardProps {
  stats: RealtimeStats;
  toolMetrics: ToolMetric[];
}

export function MetricsDashboard({ stats, toolMetrics }: MetricsDashboardProps) {
  const [hoveredTool, setHoveredTool] = useState<string | null>(null);

  // Math helper for mapping numbers into chart dimensions
  const maxLatency = Math.max(...toolMetrics.map((t) => t.avgLatencyMs), 1);
  const maxCalls = Math.max(...toolMetrics.map((t) => t.calls), 1);

  // Compute overall statistics
  const errorRate = stats.totalRequests > 0 ? (stats.errorCount / stats.totalRequests) * 100 : 0;
  const avgLatency = stats.totalRequests > 0 ? stats.avgLatencyMs : 0;

  // Render a sparkline SVG path
  const makeSparklinePath = (points: number[], width: number, height: number) => {
    if (points.length < 2) return '';
    const maxVal = Math.max(...points, 1);
    const minVal = Math.min(...points, 0);
    const valRange = maxVal - minVal;
    
    return points
      .map((val, idx) => {
        const x = (idx / (points.length - 1)) * width;
        const y = height - ((val - minVal) / valRange) * (height - 4) - 2;
        return `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
      })
      .join(' ');
  };

  // Sparkline data presets (simulating historical data trends)
  const requestsSparkHistory = [12, 19, 15, 24, 35, 28, 41, 38, 54, 48, 62, stats.totalRequests % 50 + 40];
  const latencySparkHistory = [280, 310, 290, 420, 510, 380, 295, 340, 312, 298, 305, Math.round(avgLatency)];
  const errorSparkHistory = [2, 1, 3, 5, 12, 4, 1, 2, 8, 3, 2, stats.errorCount];

  return (
    <div id="metrics-dashboard-root" className="space-y-6">
      {/* Real-time Stat Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Stat Card 1: Total Requests */}
        <div className="bg-zinc-900/40 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-between h-[120px] shadow-sm relative overflow-hidden group">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider font-sans">
                Total MCP Requests
              </span>
              <h3 className="text-2xl font-bold font-display text-zinc-100">
                {stats.totalRequests.toLocaleString()}
              </h3>
            </div>
            <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-400 group-hover:bg-emerald-500/20 transition-colors">
              <Activity size={18} />
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-zinc-800/30">
            <span className="text-[10px] text-emerald-400 flex items-center gap-0.5 font-sans">
              <TrendingUp size={11} />
              +14% vs avg
            </span>
            <svg width="70" height="18" className="stroke-emerald-400 fill-none stroke-[1.5] overflow-visible">
              <path d={makeSparklinePath(requestsSparkHistory, 70, 18)} />
            </svg>
          </div>
        </div>

        {/* Stat Card 2: Average response latency */}
        <div className="bg-zinc-900/40 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-between h-[120px] shadow-sm relative overflow-hidden group">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider font-sans">
                Average Latency (NJS)
              </span>
              <h3 className={`text-2xl font-bold font-display ${avgLatency > 800 ? 'text-amber-400' : 'text-zinc-100'}`}>
                {Math.round(avgLatency)}<span className="text-sm font-normal text-zinc-500">ms</span>
              </h3>
            </div>
            <div className={`p-2 rounded-lg group-hover:opacity-90 transition-opacity ${
              avgLatency > 800 ? 'bg-amber-500/10 text-amber-400' : 'bg-teal-500/10 text-teal-400'
            }`}>
              <Clock size={18} />
            </div>
          </div>

          <div className="flex items-center justify-between mt-2 pt-2 border-t border-zinc-800/30">
            <span className={`text-[10px] font-sans ${avgLatency > 800 ? 'text-amber-400' : 'text-zinc-500'}`}>
              {avgLatency > 800 ? '⚠️ High-latency warnings active' : '✔ Normal latency bounds'}
            </span>
            <svg width="70" height="18" className={`fill-none stroke-[1.5] overflow-visible ${
              avgLatency > 800 ? 'stroke-amber-400' : 'stroke-teal-400'
            }`}>
              <path d={makeSparklinePath(latencySparkHistory, 70, 18)} />
            </svg>
          </div>
        </div>

        {/* Stat Card 3: MCP Error Rate */}
        <div className="bg-zinc-900/40 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-between h-[120px] shadow-sm relative overflow-hidden group">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider font-sans">
                RPC-Level Errors
              </span>
              <h3 className={`text-2xl font-bold font-display ${errorRate > 12 ? 'text-rose-400 animate-pulse' : 'text-zinc-100'}`}>
                {errorRate.toFixed(1)}<span className="text-sm font-normal text-zinc-500">%</span>
              </h3>
            </div>
            <div className={`p-2 rounded-lg group-hover:opacity-90 transition-opacity ${
              errorRate > 12 ? 'bg-rose-500/10 text-rose-400 animate-pulse' : 'bg-blue-500/10 text-blue-400'
            }`}>
              <ShieldCheck size={18} />
            </div>
          </div>

          <div className="flex items-center justify-between mt-2 pt-2 border-t border-zinc-800/30">
            <span className={`text-[10px] font-sans ${errorRate > 12 ? 'text-rose-400 font-bold' : 'text-zinc-500'}`}>
              {stats.errorCount} failures logged today
            </span>
            <svg width="70" height="18" className={`fill-none stroke-[1.5] overflow-visible ${
              errorRate > 12 ? 'stroke-rose-400' : 'stroke-blue-400'
            }`}>
              <path d={makeSparklinePath(errorSparkHistory, 70, 18)} />
            </svg>
          </div>
        </div>

        {/* Stat Card 4: Bandwidth processed */}
        <div className="bg-zinc-900/40 border border-zinc-800/80 rounded-xl p-4 flex flex-col justify-between h-[120px] shadow-sm relative overflow-hidden group">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-[11px] font-medium text-zinc-500 uppercase tracking-wider font-sans">
                NJS Payload Volume
              </span>
              <h3 className="text-2xl font-bold font-display text-zinc-100">
                {(stats.bytesTransferred / 1024).toFixed(1)}<span className="text-sm font-normal text-zinc-500">KB</span>
              </h3>
            </div>
            <div className="p-2 bg-purple-500/10 text-purple-400 group-hover:bg-purple-500/20 transition-colors">
              <Database size={18} />
            </div>
          </div>

          <div className="flex items-center justify-between mt-2 pt-2 border-t border-zinc-800/30">
            <span className="text-[10px] text-zinc-500 font-sans">
              Proxy buffer standard limit: 128KB
            </span>
            <span className="text-[10px] text-purple-400 font-mono">
              ~{stats.totalRequests * 140}B payload/avg
            </span>
          </div>
        </div>
      </div>

      {/* Main Charts Bento Container */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Bento: Tool Latency Spotter (Identifies High-Latency calls) */}
        <div className="bg-zinc-900/45 border border-zinc-800/85 rounded-2xl p-5 shadow-xl flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="space-y-1">
              <h4 className="text-sm font-semibold text-zinc-200 uppercase tracking-wider font-sans">
                Tool Execution Latency Comparing List
              </h4>
              <p className="text-[11px] text-zinc-500 font-sans">
                Spotting High-Latency MCP Tool Calls (warnings trigger above 1000ms threshold).
              </p>
            </div>
            <Sliders size={15} className="text-amber-400" />
          </div>

          {/* SVG Latency Bar Chart */}
          <div id="latency-bar-chart" className="flex-1 min-h-[220px] flex flex-col justify-around gap-3 pt-2 relative">
            {toolMetrics.map((tool) => {
              const isHighLatency = tool.avgLatencyMs >= 1000;
              const percentage = (tool.avgLatencyMs / maxLatency) * 82; // Cap at 82% to fit tags
              const isHovered = hoveredTool === tool.name;

              return (
                <div
                  key={tool.name}
                  className={`flex flex-col gap-1 transition-all p-2 rounded-lg ${
                    isHovered ? 'bg-zinc-800/50 scale-[1.01]' : 'hover:bg-zinc-900/30'
                  }`}
                  onMouseEnter={() => setHoveredTool(tool.name)}
                  onMouseLeave={() => setHoveredTool(null)}
                >
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-zinc-300 truncate max-w-[220px] sm:max-w-xs font-semibold">
                      {tool.name}
                    </span>
                    <span className={`font-semibold ${isHighLatency ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {tool.avgLatencyMs}ms
                    </span>
                  </div>

                  {/* Progressive indicator bar */}
                  <div className="h-6 w-full bg-zinc-950/60 rounded-md border border-zinc-800/50 overflow-hidden flex items-center relative">
                    <div
                      className={`h-full rounded-r transition-all duration-500 ease-out ${
                        isHighLatency
                          ? 'bg-gradient-to-r from-amber-600/60 to-amber-500/80 border-r border-amber-400'
                          : 'bg-gradient-to-r from-emerald-600/40 to-emerald-500/60 border-r border-emerald-400'
                      }`}
                      style={{ width: `${percentage}%` }}
                    />
                    
                    {/* Visual details on overlay */}
                    <span className="absolute left-3 text-[10px] text-zinc-500 font-medium font-mono">
                      Calls counted: {tool.calls}
                    </span>

                    {isHighLatency && (
                      <span className="absolute right-3 text-[9px] text-amber-400 bg-amber-950/40 px-1 py-0.5 rounded border border-amber-900/30 flex items-center gap-0.5 font-bold animate-pulse">
                        <AlertCircle size={10} /> LATENCY WARNING
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Bento: Real-time traffic stream lines */}
        <div className="bg-zinc-900/45 border border-zinc-800/85 rounded-2xl p-5 shadow-xl flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="space-y-1">
              <h4 className="text-sm font-semibold text-zinc-200 uppercase tracking-wider font-sans">
                Real-Time Traffic Stream Trend
              </h4>
              <p className="text-[11px] text-zinc-500 font-sans">
                Monitoring concurrent server throughput rates and failures dynamically.
              </p>
            </div>
            <Sparkles size={15} className="text-emerald-400" />
          </div>

          {/* SVG Real-time Area Chart graph displaying logs */}
          <div id="traffic-stream-chart" className="flex-1 min-h-[220px] bg-zinc-950/40 border border-zinc-800/50 rounded-xl p-4 flex flex-col justify-between relative overflow-hidden">
            {/* Overlay grid lines */}
            <div className="absolute inset-0 flex flex-col justify-between p-4 pointer-events-none opacity-20">
              <div className="border-b border-zinc-700 w-full" />
              <div className="border-b border-zinc-700 w-full" />
              <div className="border-b border-zinc-700 w-full" />
              <div className="border-b border-zinc-700 w-full" />
            </div>

            {/* Custom SVG line */}
            <div className="flex-1 w-full relative h-[155px]">
              <svg className="w-full h-full" style={{ overflow: 'visible' }}>
                <defs>
                  <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity="0.15" />
                    <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                  </linearGradient>
                  <linearGradient id="errorGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.10" />
                    <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Grid vertical markers */}
                <line x1="20%" y1="0" x2="20%" y2="100%" stroke="#1f2937" strokeWidth="1" strokeDasharray="3,3" />
                <line x1="40%" y1="0" x2="40%" y2="100%" stroke="#1f2937" strokeWidth="1" strokeDasharray="3,3" />
                <line x1="60%" y1="0" x2="60%" y2="100%" stroke="#1f2937" strokeWidth="1" strokeDasharray="3,3" />
                <line x1="80%" y1="0" x2="80%" y2="100%" stroke="#1f2937" strokeWidth="1" strokeDasharray="3,3" />

                {/* Curved Active line (representing traffic) */}
                <path
                  d="M 0 110 Q 50 40 100 80 T 200 40 T 300 120 T 400 30"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2.5"
                  className="stroke-linecap-round"
                />
                
                {/* Underlay area */}
                <path
                  d="M 0 110 Q 50 40 100 80 T 200 40 T 300 120 T 400 30 L 400 155 L 0 155 Z"
                  fill="url(#chartGrad)"
                />

                {/* Error trend overlay lines */}
                <path
                  d="M 0 148 Q 50 140 100 145 T 200 110 T 300 135 T 400 140"
                  fill="none"
                  stroke="#ef4444"
                  strokeWidth="1.5"
                  strokeDasharray="4,2"
                />
                
                {/* Glow tracker node */}
                <circle cx="200" cy="40" r="5" fill="#10b981" className="animate-ping" />
                <circle cx="200" cy="40" r="3" fill="#10b981" />
              </svg>

              {/* Float markers */}
              <div className="absolute top-[28px] left-[185px] bg-emerald-950/80 border border-emerald-500/30 rounded py-0.5 px-1.5 text-[9px] text-emerald-400 font-bold font-mono">
                92 rps (peak)
              </div>
            </div>

            {/* X Axis indicator tags */}
            <div className="flex items-center justify-between text-[10px] text-zinc-600 font-mono mt-2 pt-2 border-t border-zinc-900">
              <span>-60 sec</span>
              <span>-45 sec</span>
              <span>-30 sec</span>
              <span>-15 sec</span>
              <span>Primary (Live)</span>
            </div>

            {/* Legends */}
            <div className="flex items-center gap-4 mt-1 text-[10px] font-mono">
              <div className="flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                <span className="text-zinc-500">Total Throughput</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="h-0.5 w-3 bg-rose-500 border-dashed" />
                <span className="text-rose-500 font-medium">RPC error-frequency rate</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of details: Top performing tools checklist */}
      <div className="bg-zinc-900/45 border border-zinc-800/85 rounded-2xl p-5 shadow-xl">
        <h4 className="text-sm font-semibold text-zinc-200 uppercase tracking-wider font-sans mb-4 flex items-center gap-1.5">
          <Sliders size={15} className="text-teal-400" />
          Individual Tool Analytical Posture
        </h4>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-sans">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-500 text-[10px] uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">MCP Target Tool name</th>
                <th className="py-3 px-4 font-semibold text-right">Sum of Requests</th>
                <th className="py-3 px-4 font-semibold text-right">Average Latency (ms)</th>
                <th className="py-3 px-4 font-semibold text-right">Errors Rate</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 font-mono">
              {toolMetrics.map((tool) => {
                const errorPercent = tool.calls > 0 ? (tool.errors / tool.calls) * 100 : 0;
                
                let perfLevel = 'text-emerald-400 bg-emerald-950/20 border-emerald-900/40';
                let perfLabel = 'Optimal';
                if (tool.avgLatencyMs > 1000) {
                  perfLevel = 'text-amber-400 bg-amber-950/20 border-amber-900/40';
                  perfLabel = 'Degraded';
                } else if (errorPercent > 10) {
                  perfLevel = 'text-rose-400 bg-rose-950/20 border-rose-900/40';
                  perfLabel = 'High Error';
                }

                return (
                  <tr key={tool.name} className="hover:bg-zinc-900/20 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2">
                        <Cpu size={12} className="text-zinc-600" />
                        <div>
                          <div className="text-zinc-200 font-medium font-sans text-xs">{tool.displayName}</div>
                          <div className="text-[10px] text-zinc-500">{tool.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-right text-zinc-300">
                      {tool.calls}
                    </td>
                    <td className={`py-3.5 px-4 text-right ${tool.avgLatencyMs > 1000 ? 'text-amber-400 font-bold' : 'text-zinc-300'}`}>
                      {tool.avgLatencyMs}ms
                    </td>
                    <td className={`py-3.5 px-4 text-right ${tool.errors > 5 ? 'text-rose-400 font-bold' : 'text-zinc-400'}`}>
                      {tool.errors} <span className="text-[9px] text-zinc-600">({errorPercent.toFixed(0)}%)</span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${perfLevel}`}>
                        {perfLabel}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
