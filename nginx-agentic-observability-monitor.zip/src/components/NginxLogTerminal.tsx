/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Trash2, Download, Search, Terminal, ArrowDown } from 'lucide-react';
import { McpLogEntry } from '../types';

interface NginxLogTerminalProps {
  logs: McpLogEntry[];
  onClear: () => void;
}

export function NginxLogTerminal({ logs, onClear }: NginxLogTerminalProps) {
  const [filter, setFilter] = useState<'all' | 'success' | 'error' | 'timeout'>('all');
  const [search, setSearch] = useState('');
  const [isAutoScroll, setIsAutoScroll] = useState(true);
  const [isPaused, setIsPaused] = useState(false);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Store logs locally when paused to prevent updating visually, but buffer them
  const [displayLogs, setDisplayLogs] = useState<McpLogEntry[]>(logs);
  const bufferedLogsRef = useRef<McpLogEntry[]>([]);

  useEffect(() => {
    if (!isPaused) {
      setDisplayLogs(logs);
    } else {
      // Buffer incoming logs
      bufferedLogsRef.current = logs;
    }
  }, [logs, isPaused]);

  useEffect(() => {
    if (isAutoScroll && terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [displayLogs, isAutoScroll]);

  const filteredLogs = displayLogs.filter((log) => {
    const matchesFilter = filter === 'all' || log.status === filter;
    const matchesSearch =
      search === '' ||
      log.rawLog.toLowerCase().includes(search.toLowerCase()) ||
      log.mcpToolName.toLowerCase().includes(search.toLowerCase()) ||
      log.client.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleDownloadLogs = () => {
    const logText = filteredLogs.map((l) => l.rawLog).join('\n');
    const blob = new Blob([logText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nginx_mcp_access_${new Date().toISOString().slice(0, 10)}.log`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleTogglePause = () => {
    if (isPaused) {
      // Catch up with latest logs when unpausing
      setDisplayLogs(logs);
    }
    setIsPaused(!isPaused);
  };

  return (
    <div id="nginx-log-terminal-container" className="flex flex-col bg-zinc-950 border border-zinc-800 rounded-xl overflow-hidden font-mono text-zinc-300 shadow-2xl h-[410px]">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between px-4 py-3 bg-zinc-900/80 border-b border-zinc-800 gap-3">
        <div className="flex items-center gap-2">
          <Terminal size={16} className="text-emerald-400" />
          <span className="text-xs font-semibold text-zinc-100 uppercase tracking-wider">
            NGINX Access Logs (NJS telemetry stream)
          </span>
          {isPaused && (
            <span className="px-2 py-0.5 text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded font-semibold animate-pulse">
              PAUSED
            </span>
          )}
        </div>

        {/* Toolbar controls */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {/* Pause / Resume Button */}
          <button
            onClick={handleTogglePause}
            className={`flex items-center gap-1 px-2.5 py-1 rounded border transition-colors ${
              isPaused
                ? 'bg-zinc-800 border-zinc-700 hover:bg-zinc-700 text-zinc-200'
                : 'bg-amber-950/20 border-amber-900/50 hover:bg-amber-900/30 text-amber-400'
            }`}
            title={isPaused ? 'Resume live log tailing' : 'Pause logs to inspect content'}
          >
            {isPaused ? <Play size={12} /> : <Pause size={12} />}
            {isPaused ? 'Resume' : 'Pause'}
          </button>

          {/* Download Logs */}
          <button
            onClick={handleDownloadLogs}
            disabled={filteredLogs.length === 0}
            className="flex items-center gap-1 px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 rounded transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            title="Export filtered log lines as .log file"
          >
            <Download size={12} />
            <span>Export</span>
          </button>

          {/* Clear Log Window */}
          <button
            onClick={onClear}
            className="flex items-center gap-1 px-2.5 py-1 bg-rose-950/20 hover:bg-rose-950/40 text-rose-400 border border-rose-900/30 rounded transition-colors"
            title="Flush log view history"
          >
            <Trash2 size={12} />
            <span>Clear</span>
          </button>
        </div>
      </div>

      {/* Filters and search input */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between p-3 bg-zinc-900/40 border-b border-zinc-800 gap-3">
        {/* Log Segment Toggles */}
        <div className="flex items-center gap-1.5 p-0.5 bg-zinc-950 rounded-lg border border-zinc-800 max-w-full overflow-x-auto">
          {(['all', 'success', 'error', 'timeout'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setFilter(t)}
              className={`px-3 py-1 text-[11px] font-medium rounded-md capitalize transition-all ${
                filter === t
                  ? 'bg-zinc-800 text-white shadow-sm border border-zinc-700'
                  : 'text-zinc-500 hover:text-zinc-300 border border-transparent'
              }`}
            >
              {t === 'all' ? 'All Logs' : t === 'success' ? '✔ Success' : t === 'error' ? '✖ MCP Errors' : '⏰ Gateway Timeout'}
            </button>
          ))}
        </div>

        {/* Live Search */}
        <div className="relative flex-1 md:max-w-xs">
          <Search size={12} className="absolute left-2.5 top-2.5 text-zinc-500" />
          <input
            type="text"
            placeholder="Filter: client_ip, tool_name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-[11px] text-zinc-300 placeholder-zinc-600 focus:outline-none focus:border-emerald-500/50 transition-colors"
          />
        </div>
      </div>

      {/* Log Console Output Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-1.5 scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-zinc-950 scanline leading-relaxed">
        {filteredLogs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full py-10 text-center text-zinc-500 gap-2">
            <Terminal size={24} className="text-zinc-700 animate-pulse" />
            <p className="text-xs">No matching telemetry logs found.</p>
            <p className="text-[10px] text-zinc-600 max-w-xs">
              Use the playground panel to fire some MCP requests and see them intercepted by NGINX real time!
            </p>
          </div>
        ) : (
          filteredLogs.map((log) => {
            // Pick a highlight color based on the status
            const isError = log.status === 'error';
            const isTimeout = log.status === 'timeout';
            
            let colorClass = 'text-zinc-400';
            let labelClass = 'text-zinc-500';
            if (isError) {
              colorClass = 'text-rose-400 font-semibold';
              labelClass = 'text-rose-500/70';
            } else if (isTimeout) {
              colorClass = 'text-amber-500 font-semibold';
              labelClass = 'text-amber-600/70';
            } else if (log.latencyMs > 1000) {
              colorClass = 'text-amber-300';
              labelClass = 'text-amber-500/70';
            } else if (log.status === 'success') {
              colorClass = 'text-zinc-300';
              labelClass = 'text-emerald-500';
            }

            return (
              <div
                key={log.id}
                className={`py-1.5 px-2.5 text-xs rounded hover:bg-zinc-900/80 transition-colors border-l-2 border-transparent hover:border-zinc-700 ${
                  isError ? 'bg-rose-950/10 border-l-rose-500/40' : isTimeout ? 'bg-amber-950/10 border-l-amber-500/40' : ''
                }`}
              >
                {/* Visual JSON Log components highlighting NJS exports */}
                <div className="flex flex-wrap items-center gap-1 ml-1 text-[11px] leading-relaxed">
                  <span className="text-blue-400">{log.remoteAddr}</span>
                  <span className="text-zinc-600">[{log.timestamp}]</span>
                  <span className="text-emerald-400 font-medium">"{log.httpMethod} {log.path}"</span>
                  <span className={`px-1 rounded ${log.httpStatus >= 400 ? 'bg-rose-950/40 text-rose-400' : 'text-zinc-400'}`}>
                    {log.httpStatus}
                  </span>
                  <span className="text-zinc-500">{log.bodyBytesSent}B</span>
                  
                  {/* NJS Custom Variables Block */}
                  <span className="text-zinc-700">|</span>
                  <span className="text-zinc-500 font-semibold">mcp_method=</span>
                  <span className="text-purple-400">"{log.mcpMethod}"</span>
                  
                  {log.mcpToolName !== '-' && (
                    <>
                      <span className="text-zinc-500 font-semibold">mcp_tool=</span>
                      <span className="text-teal-400">"{log.mcpToolName}"</span>
                    </>
                  )}

                  <span className="text-zinc-500 font-semibold">mcp_status=</span>
                  <span className={isError ? 'text-rose-400 font-bold' : isTimeout ? 'text-amber-500 font-bold' : 'text-emerald-400'}>
                    "{log.status}"
                  </span>

                  <span className="text-zinc-500 font-semibold">latency=</span>
                  <span className={`font-semibold ${log.latencyMs > 1000 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {log.latencyMs}ms
                  </span>

                  {/* Upstream server label if successful */}
                  <span className="text-zinc-600 font-light">(backends: {log.client.includes('claude') ? 'mcp-01' : 'mcp-02'})</span>
                </div>
                
                {/* If the log line is selected or error exists, show error message detail */}
                {log.errorMessage && (
                  <div className="mt-1 ml-4 pl-3.5 border-l border-rose-800/60 text-[10px] text-rose-400/80 italic">
                    ↳ JSON-RPC-Error: {log.errorMessage}
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={terminalEndRef} />
      </div>

      {/* Footer statistics block */}
      <div className="flex items-center justify-between px-4 py-2 bg-zinc-900 border-t border-zinc-800 text-[11px] text-zinc-500">
        <div className="flex items-center gap-2">
          <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>Tail status: Live Connection Socket active</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Displaying: {filteredLogs.length} of {displayLogs.length} entries</span>
          <button
            onClick={() => setIsAutoScroll(!isAutoScroll)}
            className={`flex items-center gap-1 transition-colors ${isAutoScroll ? 'text-emerald-400 hover:text-emerald-300' : 'text-zinc-500 hover:text-zinc-400'}`}
          >
            <span>Auto-Scroll</span>
            <ArrowDown size={11} className={isAutoScroll ? 'animate-bounce' : ''} />
          </button>
        </div>
      </div>
    </div>
  );
}
