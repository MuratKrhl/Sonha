/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FileCode, Clipboard, Check, HelpCircle, Layers, Server, RefreshCw } from 'lucide-react';
import { CONFIGS } from '../data';

export function ConfigFileExplorer() {
  const [activeConfigId, setActiveConfigId] = useState('nginx-conf');
  const [isCopied, setIsCopied] = useState(false);

  const activeConfig = CONFIGS.find((c) => c.id === activeConfigId) || CONFIGS[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeConfig.code);
    setIsCopied(true);
    setTimeout(() => {
      setIsCopied(false);
    }, 2000);
  };

  return (
    <div id="config-file-explorer-container" className="flex flex-col lg:flex-row bg-zinc-900/45 border border-zinc-800/80 rounded-2xl overflow-hidden shadow-xl">
      {/* Sidebar with files selection */}
      <div className="w-full lg:w-64 bg-zinc-950/60 border-b lg:border-b-0 lg:border-r border-zinc-800/60 p-4">
        <h3 className="text-xs font-semibold text-zinc-400 uppercase tracking-widest mb-4 flex items-center gap-1.5 font-sans">
          <Layers size={13} className="text-emerald-400" />
          NJS Deploy Files
        </h3>
        <p className="text-[11px] text-zinc-500 mb-4 leading-relaxed font-sans">
          These configuration scripts are run in real production NGINX boxes mapped inside the proxy block.
        </p>

        {/* File tabs button list */}
        <div className="flex flex-row lg:flex-col gap-1 overflow-x-auto min-w-full lg:overflow-x-visible pb-2 lg:pb-0">
          {CONFIGS.map((config) => {
            const isActive = config.id === activeConfigId;
            return (
              <button
                key={config.id}
                onClick={() => setActiveConfigId(config.id)}
                className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-left text-xs font-mono transition-all border shrink-0 lg:shrink-1 ${
                  isActive
                    ? 'bg-zinc-800/80 border-zinc-700 text-white shadow-md'
                    : 'bg-transparent border-transparent text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900/40'
                }`}
              >
                <FileCode size={14} className={isActive ? 'text-emerald-400' : 'text-zinc-600'} />
                <span className="truncate">{config.filename}</span>
              </button>
            );
          })}
        </div>

        {/* Quick architecture brief */}
        <div className="hidden lg:block mt-8 p-3 bg-zinc-900/30 border border-zinc-800/40 rounded-xl space-y-2">
          <h4 className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider flex items-center gap-1 font-sans">
            <Server size={11} className="text-teal-400" />
            Gateway Engine
          </h4>
          <p className="text-[10px] text-zinc-500 leading-relaxed font-sans">
            NGINX loads the JavaScript script dynamic library <span className="font-mono text-[9px] text-teal-400 bg-zinc-950 px-1 py-0.5 rounded">ngx_http_js_module</span>, then uses event buffers to parse JSON bodies to isolate variables without halting event-driven throughput.
          </p>
        </div>
      </div>

      {/* Code viewer area */}
      <div className="flex-1 flex flex-col min-w-0 bg-zinc-950/20">
        {/* Header toolbar */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-zinc-900/30 border-b border-zinc-800/60">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-mono text-zinc-200 text-xs font-bold font-mono">
                {activeConfig.filename}
              </span>
              <span className="text-[9px] uppercase px-1.5 py-0.5 bg-zinc-800 text-zinc-400 rounded-md tracking-wider font-mono">
                {activeConfig.language}
              </span>
            </div>
            <p className="text-[11px] text-zinc-500 max-w-2xl font-sans leading-relaxed">
              {activeConfig.description}
            </p>
          </div>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-800 rounded-lg transition-all text-xs"
            title="Copy source code to clipboard"
          >
            {isCopied ? (
              <>
                <Check size={12} className="text-emerald-400" />
                <span className="text-emerald-400 font-medium">Copied</span>
              </>
            ) : (
              <>
                <Clipboard size={12} />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>

        {/* Source viewer content with line numbers */}
        <div className="flex-1 p-5 overflow-auto max-h-[460px] scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-zinc-950">
          <pre className="text-[11px] font-mono text-zinc-300 leading-relaxed overflow-x-auto select-text flex">
            {/* Sourced line numbers column */}
            <div className="text-zinc-600 text-right pr-4 select-none border-r border-zinc-800/60 mr-4 font-light text-[11px]" style={{ minWidth: '2.5rem' }}>
              {activeConfig.code.split('\n').map((_, index) => (
                <div key={index} className="h-5">
                  {index + 1}
                </div>
              ))}
            </div>

            {/* Structured code highlights */}
            <div className="flex-1 font-mono text-[11.5px] text-zinc-300 whitespace-pre-wrap">
              {activeConfig.code.split('\n').map((line, idx) => {
                // Highlighting specific terms for visual aesthetics of configs
                let renderedLine = line;

                // Simple highlighted lines
                const highlights = [
                  { pattern: /js_import mcp from conf.d\/mcp.js;/g, color: 'text-teal-400 font-semibold' },
                  { pattern: /js_set \$mcp_method    mcp.getMethod;/g, color: 'text-amber-400 font-semibold' },
                  { pattern: /js_set \$mcp_tool_name mcp.getToolName;/g, color: 'text-purple-400 font-semibold' },
                  { pattern: /js_set \$mcp_status    mcp.getMcpStatus;/g, color: 'text-emerald-400 font-semibold' },
                  { pattern: /log_format agentic_observability/g, color: 'text-blue-400 font-bold' },
                  { pattern: /location \/mcp/g, color: 'text-rose-400 font-bold' },
                  { pattern: /function getMethod/g, color: 'text-teal-400 font-bold' },
                  { pattern: /function getToolName/g, color: 'text-purple-400 font-bold' },
                  { pattern: /function getMcpStatus/g, color: 'text-emerald-400 font-bold' },
                  { pattern: /function analyzeResponse/g, color: 'text-amber-400 font-bold' },
                  { pattern: /r\.headersOut\['X-MCP-Execution-Error'\]/g, color: 'text-pink-400 font-mono' },
                  { pattern: /export default \{ getMethod, getToolName, getMcpStatus, analyzeResponse \};/g, color: 'text-teal-400 font-semibold' },
                ];

                let matchesAnyHighlight = false;
                let finalClass = 'h-5 tracking-wide';

                for (const h of highlights) {
                  if (renderedLine.match(h.pattern)) {
                    matchesAnyHighlight = true;
                    // Let's wrap matches in inline styling or highlight the full line if critical
                    if (renderedLine.includes('js_import') || renderedLine.includes('js_set') || renderedLine.includes('log_format') || renderedLine.includes('location')) {
                      finalClass += ' bg-teal-500/5 text-zinc-100 rounded px-1 border-l border-teal-500/30';
                    }
                  }
                }

                // If line contains comments, make it grey
                if (line.trim().startsWith('//') || line.trim().startsWith('#') || line.trim().startsWith('*')) {
                  finalClass += ' text-zinc-600 italic font-light';
                }

                return (
                  <div key={idx} className={finalClass}>
                    {/* Rendered line */}
                    {line.includes('js_import') || line.includes('js_set') || line.includes('log_format') ? (
                      <span className="text-teal-300">{line}</span>
                    ) : line.includes('function ') ? (
                      <span className="text-zinc-100 font-medium">{line}</span>
                    ) : (
                      line
                    )}
                  </div>
                );
              })}
            </div>
          </pre>
        </div>

        {/* Explain code snippets */}
        <div className="bg-zinc-900/60 p-4 border-t border-zinc-800/60 flex items-start gap-2.5">
          <HelpCircle size={16} className="text-teal-400 shrink-0 mt-0.5" />
          <p className="text-[11px] text-zinc-400 leading-relaxed font-sans">
            <strong className="text-zinc-200">Observability Metric:</strong> By inspecting <span className="font-mono text-[10px] text-amber-400 bg-zinc-950 px-1 py-0.5 rounded">r.requestText</span> during the HTTP POST payload, NJS reads JSON RPC parameters instantly. If a task returns an error or fails, <span className="font-mono text-[10px] text-teal-400 bg-zinc-950 px-1 py-0.5 rounded">analyzeResponse()</span> modifies the client-facing tracking headers to inform logging without interrupting connection streams.
          </p>
        </div>
      </div>
    </div>
  );
}
